## Packages
jspdf | Generate professional PDF reports
jspdf-autotable | Table support for PDF generation
framer-motion | Smooth animations and transitions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
colors: {
  uaf: {
    DEFAULT: "#006747",
    light: "#008f63",
    dark: "#004d35",
    glow: "#00ffaf"
  },
  midnight: {
    900: "#050505",
    800: "#0a0a0a",
    700: "#121212",
    600: "#1a1a1a"
  }
}
