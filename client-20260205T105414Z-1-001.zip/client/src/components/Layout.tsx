import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Calculator, GraduationCap, BookOpen, Mail, Menu, X, Linkedin } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home", icon: Calculator },
    { href: "/gpa", label: "GPA", icon: GraduationCap },
    { href: "/cgpa", label: "CGPA", icon: BookOpen },
    { href: "/lms", label: "Fetch LMS", icon: BookOpen }, // Re-using BookOpen for now
    { href: "/contact", label: "Contact", icon: Mail },
  ];

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Background Ambience */}
      <div className="fixed inset-0 z-[-1] pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px] opacity-30 animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px] opacity-20" />
      </div>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-header">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-xl tracking-tight text-white leading-none">UAF Calculator</span>
              <span className="text-[10px] text-white/60 font-medium tracking-wider uppercase mt-1">Premier Academic Tool</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1 bg-white/5 backdrop-blur-md px-2 py-1.5 rounded-full border border-white/10">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div className={cn(
                    "px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 flex items-center gap-2 cursor-pointer relative overflow-hidden",
                    isActive 
                      ? "text-white bg-primary shadow-lg shadow-primary/25" 
                      : "text-white/70 hover:text-white hover:bg-white/10"
                  )}>
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </div>
                </Link>
              );
            })}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <a 
              href="https://www.linkedin.com/in/muhammad-ahmad-3151112a1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hidden sm:flex w-10 h-10 rounded-full bg-white/5 border border-white/10 items-center justify-center text-white/70 hover:text-blue-400 hover:border-blue-400/30 hover:bg-blue-400/10 transition-all duration-300"
            >
              <Linkedin className="w-5 h-5" />
            </a>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-black/95 backdrop-blur-xl pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col gap-4">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <div 
                    className={cn(
                      "p-4 rounded-xl text-lg font-medium border transition-all flex items-center gap-4 cursor-pointer",
                      location === item.href
                        ? "bg-primary/20 border-primary/50 text-primary"
                        : "bg-white/5 border-white/5 text-white/80"
                    )}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <item.icon className="w-6 h-6" />
                    {item.label}
                  </div>
                </Link>
              ))}
              
              <a 
                href="https://www.linkedin.com/in/muhammad-ahmad-3151112a1" 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-4 rounded-xl bg-[#0077b5]/20 border border-[#0077b5]/30 text-[#0077b5] flex items-center gap-4 font-medium mt-4"
              >
                <Linkedin className="w-6 h-6" />
                Connect on LinkedIn
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-grow pt-28 pb-12 container mx-auto px-4 z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {children}
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-black/50 backdrop-blur-lg py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-primary" />
              </div>
              <span className="font-display font-bold text-white">UAF Calculator</span>
            </div>
            
            <p className="text-white/40 text-sm text-center md:text-right">
              © 2025 UAF Calculator. Developed by Ahmed Khokhar.<br />
              <span className="text-white/20">University of Agriculture, Faisalabad</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
