import { useMutation } from "@tanstack/react-query";
import { api, type InsertFeedback } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSubmitFeedback() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: InsertFeedback) => {
      // Validate with schema first
      const validated = api.feedback.submit.input.parse(data);
      
      const res = await fetch(api.feedback.submit.path, {
        method: api.feedback.submit.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to submit feedback');
      }

      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Feedback Sent!",
        description: "Thank you for your message. We'll get back to you soon.",
        className: "bg-green-600 border-green-700 text-white",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
