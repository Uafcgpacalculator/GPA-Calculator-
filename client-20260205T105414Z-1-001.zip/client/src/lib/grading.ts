// UAF Official Grading System Logic

interface GradeRange {
  marks: { min: number; max: number };
  qp: number;
  grade: string;
}

type GradingSystem = Record<number, GradeRange[]>;

export const uafGradingSystem: GradingSystem = {
  1: [
    { marks: { min: 0, max: 7 }, qp: 0, grade: "F" },
    { marks: { min: 8, max: 8 }, qp: 1, grade: "D" },
    { marks: { min: 9, max: 9 }, qp: 1.5, grade: "D" },
    { marks: { min: 10, max: 10 }, qp: 2, grade: "C" },
    { marks: { min: 11, max: 11 }, qp: 2.33, grade: "C" },
    { marks: { min: 12, max: 12 }, qp: 2.67, grade: "C" },
    { marks: { min: 13, max: 13 }, qp: 3, grade: "B" },
    { marks: { min: 14, max: 14 }, qp: 3.33, grade: "B" },
    { marks: { min: 15, max: 15 }, qp: 3.67, grade: "B" },
    { marks: { min: 16, max: 20 }, qp: 4, grade: "A" }
  ],
  2: [
    { marks: { min: 0, max: 15 }, qp: 0, grade: "F" },
    { marks: { min: 16, max: 16 }, qp: 2, grade: "D" },
    { marks: { min: 17, max: 17 }, qp: 2.5, grade: "D" },
    { marks: { min: 18, max: 18 }, qp: 3, grade: "D" },
    { marks: { min: 19, max: 19 }, qp: 3.5, grade: "D" },
    { marks: { min: 20, max: 20 }, qp: 4, grade: "C" },
    { marks: { min: 21, max: 21 }, qp: 4.33, grade: "C" },
    { marks: { min: 22, max: 22 }, qp: 4.67, grade: "C" },
    { marks: { min: 23, max: 23 }, qp: 5, grade: "C" },
    { marks: { min: 24, max: 24 }, qp: 5.33, grade: "C" },
    { marks: { min: 25, max: 25 }, qp: 5.67, grade: "C" },
    { marks: { min: 26, max: 26 }, qp: 6, grade: "B" },
    { marks: { min: 27, max: 27 }, qp: 6.33, grade: "B" },
    { marks: { min: 28, max: 28 }, qp: 6.67, grade: "B" },
    { marks: { min: 29, max: 29 }, qp: 7, grade: "B" },
    { marks: { min: 30, max: 30 }, qp: 7.33, grade: "B" },
    { marks: { min: 31, max: 31 }, qp: 7.67, grade: "B" },
    { marks: { min: 32, max: 40 }, qp: 8, grade: "A" }
  ],
  3: [
    { marks: { min: 0, max: 23 }, qp: 0, grade: "F" },
    { marks: { min: 24, max: 24 }, qp: 3, grade: "D" },
    { marks: { min: 25, max: 25 }, qp: 3.5, grade: "D" },
    { marks: { min: 26, max: 26 }, qp: 4, grade: "D" },
    { marks: { min: 27, max: 27 }, qp: 4.5, grade: "D" },
    { marks: { min: 28, max: 28 }, qp: 5, grade: "D" },
    { marks: { min: 29, max: 29 }, qp: 5.5, grade: "D" },
    { marks: { min: 30, max: 30 }, qp: 6, grade: "C" },
    { marks: { min: 31, max: 31 }, qp: 6.33, grade: "C" },
    { marks: { min: 32, max: 32 }, qp: 6.67, grade: "C" },
    { marks: { min: 33, max: 33 }, qp: 7, grade: "C" },
    { marks: { min: 34, max: 34 }, qp: 7.33, grade: "C" },
    { marks: { min: 35, max: 35 }, qp: 7.67, grade: "C" },
    { marks: { min: 36, max: 36 }, qp: 8, grade: "C" },
    { marks: { min: 37, max: 37 }, qp: 8.33, grade: "C" },
    { marks: { min: 38, max: 38 }, qp: 8.67, grade: "C" },
    { marks: { min: 39, max: 39 }, qp: 9, grade: "B" },
    { marks: { min: 40, max: 40 }, qp: 9.33, grade: "B" },
    { marks: { min: 41, max: 41 }, qp: 9.67, grade: "B" },
    { marks: { min: 42, max: 42 }, qp: 10, grade: "B" },
    { marks: { min: 43, max: 43 }, qp: 10.33, grade: "B" },
    { marks: { min: 44, max: 44 }, qp: 10.67, grade: "B" },
    { marks: { min: 45, max: 45 }, qp: 11, grade: "B" },
    { marks: { min: 46, max: 46 }, qp: 11.33, grade: "B" },
    { marks: { min: 47, max: 47 }, qp: 11.67, grade: "B" },
    { marks: { min: 48, max: 60 }, qp: 12, grade: "A" }
  ],
  4: [
    { marks: { min: 0, max: 31 }, qp: 0, grade: "F" },
    { marks: { min: 32, max: 32 }, qp: 4, grade: "D" },
    { marks: { min: 33, max: 33 }, qp: 4.5, grade: "D" },
    { marks: { min: 34, max: 34 }, qp: 5, grade: "D" },
    { marks: { min: 35, max: 35 }, qp: 5.5, grade: "D" },
    { marks: { min: 36, max: 36 }, qp: 6, grade: "D" },
    { marks: { min: 37, max: 37 }, qp: 6.5, grade: "D" },
    { marks: { min: 38, max: 38 }, qp: 7, grade: "D" },
    { marks: { min: 39, max: 39 }, qp: 7.5, grade: "D" },
    { marks: { min: 40, max: 40 }, qp: 8, grade: "C" },
    { marks: { min: 41, max: 41 }, qp: 8.33, grade: "C" },
    { marks: { min: 42, max: 42 }, qp: 8.67, grade: "C" },
    { marks: { min: 43, max: 43 }, qp: 9, grade: "C" },
    { marks: { min: 44, max: 44 }, qp: 9.33, grade: "C" },
    { marks: { min: 45, max: 45 }, qp: 9.67, grade: "C" },
    { marks: { min: 46, max: 46 }, qp: 10, grade: "C" },
    { marks: { min: 47, max: 47 }, qp: 10.33, grade: "C" },
    { marks: { min: 48, max: 48 }, qp: 10.67, grade: "C" },
    { marks: { min: 49, max: 49 }, qp: 11, grade: "C" },
    { marks: { min: 50, max: 50 }, qp: 11.33, grade: "C" },
    { marks: { min: 51, max: 51 }, qp: 11.67, grade: "C" },
    { marks: { min: 52, max: 52 }, qp: 12, grade: "B" },
    { marks: { min: 53, max: 53 }, qp: 12.33, grade: "B" },
    { marks: { min: 54, max: 54 }, qp: 12.67, grade: "B" },
    { marks: { min: 55, max: 55 }, qp: 13, grade: "B" },
    { marks: { min: 56, max: 56 }, qp: 13.33, grade: "B" },
    { marks: { min: 57, max: 57 }, qp: 13.67, grade: "B" },
    { marks: { min: 58, max: 58 }, qp: 14, grade: "B" },
    { marks: { min: 59, max: 59 }, qp: 14.33, grade: "B" },
    { marks: { min: 60, max: 60 }, qp: 14.67, grade: "B" },
    { marks: { min: 61, max: 61 }, qp: 15, grade: "B" },
    { marks: { min: 62, max: 62 }, qp: 15.33, grade: "B" },
    { marks: { min: 63, max: 63 }, qp: 15.67, grade: "B" },
    { marks: { min: 64, max: 80 }, qp: 16, grade: "A" }
  ],
  5: [
    { marks: { min: 0, max: 39 }, qp: 0, grade: "F" },
    { marks: { min: 40, max: 40 }, qp: 5, grade: "D" },
    { marks: { min: 41, max: 41 }, qp: 5.5, grade: "D" },
    { marks: { min: 42, max: 42 }, qp: 6, grade: "D" },
    { marks: { min: 43, max: 43 }, qp: 6.5, grade: "D" },
    { marks: { min: 44, max: 44 }, qp: 7, grade: "D" },
    { marks: { min: 45, max: 45 }, qp: 7.5, grade: "D" },
    { marks: { min: 46, max: 46 }, qp: 8, grade: "D" },
    { marks: { min: 47, max: 47 }, qp: 8.5, grade: "D" },
    { marks: { min: 48, max: 48 }, qp: 9, grade: "D" },
    { marks: { min: 49, max: 49 }, qp: 9.5, grade: "D" },
    { marks: { min: 50, max: 50 }, qp: 10, grade: "C" },
    { marks: { min: 51, max: 51 }, qp: 10.33, grade: "C" },
    { marks: { min: 52, max: 52 }, qp: 10.67, grade: "C" },
    { marks: { min: 53, max: 53 }, qp: 11, grade: "C" },
    { marks: { min: 54, max: 54 }, qp: 11.33, grade: "C" },
    { marks: { min: 55, max: 55 }, qp: 11.67, grade: "C" },
    { marks: { min: 56, max: 56 }, qp: 12, grade: "C" },
    { marks: { min: 57, max: 57 }, qp: 12.33, grade: "C" },
    { marks: { min: 58, max: 58 }, qp: 12.67, grade: "C" },
    { marks: { min: 59, max: 59 }, qp: 13, grade: "C" },
    { marks: { min: 60, max: 60 }, qp: 13.33, grade: "C" },
    { marks: { min: 61, max: 61 }, qp: 13.67, grade: "C" },
    { marks: { min: 62, max: 62 }, qp: 14, grade: "C" },
    { marks: { min: 63, max: 63 }, qp: 14.33, grade: "C" },
    { marks: { min: 64, max: 64 }, qp: 14.67, grade: "C" },
    { marks: { min: 65, max: 65 }, qp: 15, grade: "B" },
    { marks: { min: 66, max: 66 }, qp: 15.33, grade: "B" },
    { marks: { min: 67, max: 67 }, qp: 15.67, grade: "B" },
    { marks: { min: 68, max: 68 }, qp: 16, grade: "B" },
    { marks: { min: 69, max: 69 }, qp: 16.33, grade: "B" },
    { marks: { min: 70, max: 70 }, qp: 16.67, grade: "B" },
    { marks: { min: 71, max: 71 }, qp: 17, grade: "B" },
    { marks: { min: 72, max: 72 }, qp: 17.33, grade: "B" },
    { marks: { min: 73, max: 73 }, qp: 17.67, grade: "B" },
    { marks: { min: 74, max: 74 }, qp: 18, grade: "B" },
    { marks: { min: 75, max: 75 }, qp: 18.33, grade: "B" },
    { marks: { min: 76, max: 76 }, qp: 18.67, grade: "B" },
    { marks: { min: 77, max: 77 }, qp: 19, grade: "B" },
    { marks: { min: 78, max: 78 }, qp: 19.33, grade: "B" },
    { marks: { min: 79, max: 79 }, qp: 19.67, grade: "B" },
    { marks: { min: 80, max: 100 }, qp: 20, grade: "A" }
  ]
};

export interface CourseResult {
  id: string;
  name: string;
  creditHours: number;
  marks: number;
  maxMarks: number;
  grade: string;
  qp: number;
  percentage: number;
}

export function getMaxMarks(creditHours: number): number {
  return creditHours * 20;
}

export function calculateCourseResult(name: string, creditHours: number, marks: number): CourseResult {
  const maxMarks = getMaxMarks(creditHours);
  const percentage = (marks / maxMarks) * 100;
  
  const gradeScale = uafGradingSystem[creditHours];
  let grade = "F";
  let qp = 0;

  if (gradeScale) {
    for (const entry of gradeScale) {
      if (marks >= entry.marks.min && marks <= entry.marks.max) {
        grade = entry.grade;
        qp = entry.qp;
        break;
      }
    }
  }

  return {
    id: crypto.randomUUID(),
    name,
    creditHours,
    marks,
    maxMarks,
    grade,
    qp,
    percentage
  };
}

export function getPerformanceAnalysis(gpa: number) {
  if (gpa >= 3.7) {
    return {
      status: 'Excellent',
      color: 'text-green-400',
      bg: 'bg-green-500/20',
      description: 'Outstanding academic performance! You are excelling in your studies.',
      icon: '🌟'
    };
  } else if (gpa >= 3.0) {
    return {
      status: 'Good',
      color: 'text-blue-400',
      bg: 'bg-blue-500/20',
      description: 'Good academic performance with a solid foundation.',
      icon: '👍'
    };
  } else if (gpa >= 2.0) {
    return {
      status: 'Satisfactory',
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/20',
      description: 'Meeting basic requirements, but improvement is needed.',
      icon: '⚠️'
    };
  } else {
    return {
      status: 'Needs Improvement',
      color: 'text-red-400',
      bg: 'bg-red-500/20',
      description: 'Immediate attention required to improve academic standing.',
      icon: '🚨'
    };
  }
}
