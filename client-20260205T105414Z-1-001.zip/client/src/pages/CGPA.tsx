import { Layout } from "@/components/Layout";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, Calculator, RefreshCw } from "lucide-react";

export default function CGPA() {
  const { toast } = useToast();

  const [inputs, setInputs] = useState({
    prevCGPA: "",
    prevCH: "",
    currentGPA: "",
    currentCH: ""
  });

  const [result, setResult] = useState<number | null>(null);

  const updateInput = (field: keyof typeof inputs, value: string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const calculate = () => {
    const pCGPA = parseFloat(inputs.prevCGPA);
    const pCH = parseFloat(inputs.prevCH);
    const cGPA = parseFloat(inputs.currentGPA);
    const cCH = parseFloat(inputs.currentCH);

    if (isNaN(pCGPA) || isNaN(pCH) || isNaN(cGPA) || isNaN(cCH)) {
      toast({
        title: "Input Error",
        description: "Please enter valid numbers for all fields.",
        variant: "destructive",
      });
      return;
    }

    if (pCGPA < 0 || pCGPA > 4 || cGPA < 0 || cGPA > 4) {
      toast({
        title: "Value Error",
        description: "GPA/CGPA must be between 0 and 4.00",
        variant: "destructive",
      });
      return;
    }

    const totalPrevQP = pCGPA * pCH;
    const totalCurrentQP = cGPA * cCH;
    const totalQP = totalPrevQP + totalCurrentQP;
    const totalCH = pCH + cCH;
    
    const newCGPA = totalQP / totalCH;
    setResult(newCGPA);

    toast({
      title: "Calculation Success",
      description: "Your new CGPA has been calculated.",
      className: "bg-primary border-primary/50 text-white",
    });
  };

  const reset = () => {
    setInputs({ prevCGPA: "", prevCH: "", currentGPA: "", currentCH: "" });
    setResult(null);
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-display font-bold text-white">CGPA Calculator</h1>
          <p className="text-white/60">Combine your previous semesters with your current performance.</p>
        </div>

        <div className="glass-card rounded-3xl p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/70">Previous CGPA</label>
              <input
                type="number"
                placeholder="e.g. 3.45"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/20"
                value={inputs.prevCGPA}
                onChange={(e) => updateInput("prevCGPA", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/70">Previous Total Credit Hours</label>
              <input
                type="number"
                placeholder="e.g. 64"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/20"
                value={inputs.prevCH}
                onChange={(e) => updateInput("prevCH", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/70">Current Semester GPA</label>
              <input
                type="number"
                placeholder="e.g. 3.80"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/20"
                value={inputs.currentGPA}
                onChange={(e) => updateInput("currentGPA", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/70">Current Semester Credit Hours</label>
              <input
                type="number"
                placeholder="e.g. 18"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/20"
                value={inputs.currentCH}
                onChange={(e) => updateInput("currentCH", e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <button
              onClick={reset}
              className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium flex items-center justify-center gap-2 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Reset
            </button>
            <button
              onClick={calculate}
              className="flex-grow px-8 py-3 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold shadow-lg shadow-primary/20 flex items-center justify-center gap-2 transition-all hover:-translate-y-0.5"
            >
              <Calculator className="w-5 h-5" /> Calculate CGPA
            </button>
          </div>
        </div>

        {result !== null && (
          <div className="glass-card rounded-3xl p-8 text-center animate-in fade-in zoom-in duration-300">
            <h3 className="text-white/60 font-medium mb-2">Your New Cumulative GPA</h3>
            <div className="text-6xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-emerald-400 text-glow">
              {result.toFixed(4)}
            </div>
            <p className="text-white/40 mt-4 text-sm">
              Based on total credit hours of {parseFloat(inputs.prevCH) + parseFloat(inputs.currentCH)}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
