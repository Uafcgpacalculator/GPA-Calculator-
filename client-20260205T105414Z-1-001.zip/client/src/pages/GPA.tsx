import { Layout } from "@/components/Layout";
import { useState } from "react";
import { calculateCourseResult, CourseResult, getPerformanceAnalysis } from "@/lib/grading";
import { generatePDF } from "@/lib/pdf-generator";
import { Plus, Trash2, Calculator, Download, RefreshCw, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function GPA() {
  const { toast } = useToast();
  
  const [courses, setCourses] = useState<Array<{ id: string; name: string; ch: string; marks: string }>>([
    { id: crypto.randomUUID(), name: "", ch: "", marks: "" }
  ]);
  
  const [results, setResults] = useState<{
    courses: CourseResult[];
    gpa: number;
    totalQP: number;
    totalCH: number;
    percentage: number;
  } | null>(null);

  const addCourse = () => {
    setCourses([...courses, { id: crypto.randomUUID(), name: "", ch: "", marks: "" }]);
  };

  const removeCourse = (id: string) => {
    if (courses.length > 1) {
      setCourses(courses.filter(c => c.id !== id));
    }
  };

  const updateCourse = (id: string, field: keyof typeof courses[0], value: string) => {
    setCourses(courses.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const calculate = () => {
    try {
      // Validation
      for (const c of courses) {
        if (!c.name || !c.ch || !c.marks) {
          throw new Error("Please fill in all fields for all courses.");
        }
        const ch = parseInt(c.ch);
        const marks = parseFloat(c.marks);
        if (ch < 1 || ch > 5) throw new Error("Credit hours must be between 1 and 5.");
        if (marks < 0 || marks > (ch * 20)) throw new Error(`Marks for ${c.name} cannot exceed ${ch * 20}.`);
      }

      const calculatedCourses = courses.map(c => calculateCourseResult(c.name, parseInt(c.ch), parseFloat(c.marks)));
      
      const totalQP = calculatedCourses.reduce((sum, c) => sum + c.qp, 0);
      const totalCH = calculatedCourses.reduce((sum, c) => sum + c.creditHours, 0);
      const gpa = totalCH > 0 ? totalQP / totalCH : 0;
      const totalWeightedPercentage = calculatedCourses.reduce((sum, c) => sum + (c.percentage * c.creditHours), 0);
      const overallPercentage = totalCH > 0 ? totalWeightedPercentage / totalCH : 0;

      setResults({
        courses: calculatedCourses,
        gpa,
        totalQP,
        totalCH,
        percentage: overallPercentage
      });

      toast({
        title: "Calculation Complete!",
        description: `Your Semester GPA is ${gpa.toFixed(2)}`,
        className: "bg-primary border-primary/50 text-white",
      });

    } catch (err: any) {
      toast({
        title: "Validation Error",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  const reset = () => {
    setCourses([{ id: crypto.randomUUID(), name: "", ch: "", marks: "" }]);
    setResults(null);
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-display font-bold text-white">GPA Calculator</h1>
          <p className="text-white/60">Calculate your semester GPA with precision.</p>
        </div>

        {/* Calculator Card */}
        <div className="glass-card rounded-3xl p-6 md:p-8 space-y-6">
          <div className="space-y-4">
            <div className="grid grid-cols-12 gap-4 text-sm font-medium text-white/50 px-2">
              <div className="col-span-12 md:col-span-5">COURSE NAME</div>
              <div className="col-span-6 md:col-span-3">CREDIT HOURS</div>
              <div className="col-span-6 md:col-span-3">MARKS</div>
              <div className="hidden md:block col-span-1"></div>
            </div>

            {courses.map((course, index) => (
              <div key={course.id} className="grid grid-cols-12 gap-4 items-center animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="col-span-12 md:col-span-5">
                  <input
                    type="text"
                    placeholder={`Course Name (e.g. Mathematics)`}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/20"
                    value={course.name}
                    onChange={(e) => updateCourse(course.id, "name", e.target.value)}
                  />
                </div>
                <div className="col-span-6 md:col-span-3">
                  <select
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all appearance-none"
                    value={course.ch}
                    onChange={(e) => updateCourse(course.id, "ch", e.target.value)}
                  >
                    <option value="" className="bg-gray-900 text-white/50">Select CH</option>
                    {[1, 2, 3, 4, 5].map(n => (
                      <option key={n} value={n} className="bg-gray-900">{n} CH (Max {n * 20})</option>
                    ))}
                  </select>
                </div>
                <div className="col-span-6 md:col-span-3">
                  <input
                    type="number"
                    placeholder="Obtained"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/20"
                    value={course.marks}
                    onChange={(e) => updateCourse(course.id, "marks", e.target.value)}
                    min="0"
                  />
                </div>
                <div className="col-span-12 md:col-span-1 flex justify-center md:justify-end">
                  <button
                    onClick={() => removeCourse(course.id)}
                    className="p-3 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all w-full md:w-auto flex items-center justify-center"
                    disabled={courses.length === 1}
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col md:flex-row gap-4 pt-4 border-t border-white/5">
            <button
              onClick={addCourse}
              className="px-6 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white font-medium flex items-center justify-center gap-2 transition-all"
            >
              <Plus className="w-4 h-4" /> Add Course
            </button>
            <div className="flex-grow" />
            <button
              onClick={reset}
              className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white font-medium flex items-center justify-center gap-2 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Reset
            </button>
            <button
              onClick={calculate}
              className="px-8 py-3 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold shadow-lg shadow-primary/20 flex items-center justify-center gap-2 transition-all hover:-translate-y-0.5"
            >
              <Calculator className="w-5 h-5" /> Calculate GPA
            </button>
          </div>
        </div>

        {/* Results Section */}
        {results && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-500">
            {/* Advice Badge */}
            <div className={cn(
              "rounded-2xl p-6 border flex items-start gap-4",
              getPerformanceAnalysis(results.gpa).bg,
              `border-${getPerformanceAnalysis(results.gpa).color.split('-')[1]}-500/30`
            )}>
              <div className="text-4xl">{getPerformanceAnalysis(results.gpa).icon}</div>
              <div>
                <h3 className={cn("text-xl font-bold", getPerformanceAnalysis(results.gpa).color)}>
                  {getPerformanceAnalysis(results.gpa).status}
                </h3>
                <p className="text-white/80 mt-1">{getPerformanceAnalysis(results.gpa).description}</p>
              </div>
            </div>

            {/* Summary Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="glass-card p-6 rounded-2xl text-center space-y-2">
                <div className="text-sm font-bold text-white/50 tracking-wider">GPA</div>
                <div className="text-4xl font-display font-bold text-primary text-glow">{results.gpa.toFixed(2)}</div>
              </div>
              <div className="glass-card p-6 rounded-2xl text-center space-y-2">
                <div className="text-sm font-bold text-white/50 tracking-wider">CREDIT HOURS</div>
                <div className="text-4xl font-display font-bold text-white">{results.totalCH}</div>
              </div>
              <div className="glass-card p-6 rounded-2xl text-center space-y-2">
                <div className="text-sm font-bold text-white/50 tracking-wider">QUALITY POINTS</div>
                <div className="text-4xl font-display font-bold text-blue-400">{results.totalQP.toFixed(1)}</div>
              </div>
              <div className="glass-card p-6 rounded-2xl text-center space-y-2">
                <div className="text-sm font-bold text-white/50 tracking-wider">PERCENTAGE</div>
                <div className="text-4xl font-display font-bold text-yellow-400">{results.percentage.toFixed(1)}%</div>
              </div>
            </div>

            {/* Breakdown Table */}
            <div className="glass-card rounded-2xl overflow-hidden border border-white/10">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-white/5 text-white/50 text-xs font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4">📚 Course</th>
                      <th className="p-4 text-center">🕒 Credit Hours</th>
                      <th className="p-4 text-center">Marks</th>
                      <th className="p-4 text-center">🎓 Grade</th>
                      <th className="p-4 text-center">💎 Quality Points</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {results.courses.map((c) => (
                      <tr key={c.id} className="text-white/90 hover:bg-white/5 transition-colors">
                        <td className="p-4 font-medium">{c.name}</td>
                        <td className="p-4 text-center">{c.creditHours}</td>
                        <td className="p-4 text-center">{c.marks}/{c.maxMarks}</td>
                        <td className="p-4 text-center">
                          <span className={cn(
                            "px-3 py-1 rounded-full text-sm font-bold",
                            c.grade === 'A' ? "bg-green-500/20 text-green-400" :
                            c.grade === 'B' ? "bg-blue-500/20 text-blue-400" :
                            c.grade === 'C' ? "bg-yellow-500/20 text-yellow-400" :
                            "bg-red-500/20 text-red-400"
                          )}>
                            {c.grade}
                          </span>
                        </td>
                        <td className="p-4 text-center font-mono">{c.qp.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-center">
              <button
                onClick={() => generatePDF(results)}
                className="px-8 py-4 rounded-xl bg-white text-black font-bold hover:bg-gray-100 shadow-xl transition-all hover:-translate-y-1 flex items-center gap-2"
              >
                <Download className="w-5 h-5" /> Download Professional Report
              </button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
