import { Layout } from "@/components/Layout";
import { Link } from "wouter";
import { GraduationCap, BookOpen, ExternalLink, Mail, ArrowRight } from "lucide-react";

export default function Home() {
  const features = [
    {
      title: "Calculate GPA",
      description: "Precise semester GPA calculation with detailed course breakdown and advice.",
      icon: GraduationCap,
      href: "/gpa",
      color: "from-green-500 to-emerald-700",
    },
    {
      title: "Calculate CGPA",
      description: "Track your cumulative performance across semesters with accuracy.",
      icon: BookOpen,
      href: "/cgpa",
      color: "from-blue-500 to-indigo-700",
    },
    {
      title: "Fetch LMS Result",
      description: "Access your official UAF LMS results directly through our secure portal.",
      icon: ExternalLink,
      href: "/lms",
      color: "from-purple-500 to-violet-700",
    },
    {
      title: "Contact Support",
      description: "Have questions or suggestions? Reach out to the developer directly.",
      icon: Mail,
      href: "/contact",
      color: "from-orange-500 to-red-700",
    },
  ];

  return (
    <Layout>
      <div className="max-w-5xl mx-auto space-y-16">
        
        {/* Hero Section */}
        <div className="text-center space-y-6 py-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium animate-fade-in-up">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            UAF’s Premier Academic Tool
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 tracking-tight leading-tight">
            Master Your <br/>
            <span className="text-primary text-glow">Academic Success</span>
          </h1>
          
          <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-light leading-relaxed">
            The most advanced and precise GPA calculator for University of Agriculture, Faisalabad students. Track performance, analyze grades, and plan your future.
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Link href="/gpa">
              <div className="px-8 py-4 rounded-xl bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all duration-300 transform hover:-translate-y-1 cursor-pointer flex items-center gap-2">
                Start Calculating <ArrowRight className="w-5 h-5" />
              </div>
            </Link>
            <Link href="/lms">
              <div className="px-8 py-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white font-semibold backdrop-blur-md transition-all duration-300 cursor-pointer">
                Check LMS
              </div>
            </Link>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature, i) => (
            <Link key={i} href={feature.href}>
              <div className="group relative p-8 rounded-3xl bg-card border border-white/5 hover:border-white/10 overflow-hidden transition-all duration-300 cursor-pointer h-full">
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                
                <div className="relative z-10">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-lg mb-6 group-hover:scale-110 transition-transform duration-500`}>
                    <feature.icon className="w-7 h-7 text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  
                  <p className="text-white/60 leading-relaxed">
                    {feature.description}
                  </p>
                  
                  <div className="mt-6 flex items-center gap-2 text-sm font-medium text-white/40 group-hover:text-white transition-colors">
                    Access Tool <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

      </div>
    </Layout>
  );
}
