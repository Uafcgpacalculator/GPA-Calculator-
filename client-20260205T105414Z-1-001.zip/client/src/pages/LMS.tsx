import { Layout } from "@/components/Layout";

export default function LMS() {
  return (
    <Layout>
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-display font-bold text-white">Fetch LMS Result</h1>
          <p className="text-white/60">Access your official results directly within our secure interface.</p>
        </div>

        <div className="glass-card rounded-3xl overflow-hidden border border-white/10 relative h-[800px] w-full bg-white">
          <div className="absolute inset-0 overflow-hidden">
             {/* 
               Masking Strategy:
               The target site likely has a header we want to hide.
               We use negative margins and scaling to crop the viewport of the iframe.
               Note: This is a best-effort approach since cross-origin styles cannot be injected.
             */}
            <iframe 
              src="https://uafcalculator.live" 
              className="w-full h-[120%] border-none"
              style={{
                marginTop: '-100px', // Adjust to hide header
                transform: 'scale(1.0)',
                transformOrigin: 'top center'
              }}
              title="UAF LMS Result Fetcher"
            />
          </div>
          
          {/* Overlay for branding consistency if needed, but keeping it minimal for usability */}
        </div>
        
        <p className="text-center text-white/30 text-xs">
          Content is loaded securely from official sources. We do not store your credentials.
        </p>
      </div>
    </Layout>
  );
}
