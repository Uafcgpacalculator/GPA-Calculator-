import { db } from "./db";
import { feedback, type InsertFeedback } from "@shared/schema";

export interface IStorage {
  createFeedback(feedback: InsertFeedback): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async createFeedback(insertFeedback: InsertFeedback): Promise<void> {
    await db.insert(feedback).values(insertFeedback);
  }
}

export const storage = new DatabaseStorage();
